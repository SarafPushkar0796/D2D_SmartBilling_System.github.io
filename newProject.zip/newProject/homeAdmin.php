<?php
include("includes/header.php");
include("includes/config.php");
include("includes/checkExistingEmail.php");
session_start();
if (check_admin()) {
	header("Location:admin.php");
}
$name=$_SESSION['name'];

// Getting online users
// $sql="SELECT * FROM login_details";
// $result=mysqli_query($sql);
$users=mysqli_query($con,"SELECT * FROM login_details;");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/adminNav.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>

<body style="background-color: #74EBD5;
background-image: linear-gradient(239deg, #74EBD5 0%, #9FACE6 100%);">

  <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color:#fafafa;box-shadow: 0 3px 40px rgba(0,0,0,0.3);">
  <img src="images/d2d2.png" style="margin: 10px;height:80px; width:80px;"/>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a href="#" class="active" style="font-size:20px;">
          <i class="fa fa-user"></i> Online Users
        </a>
      </li>
      <li class="nav-item">
        <a href="#" style="font-size:20px;">
            <i class="fa fa-envelope"></i> Option 2
        </a>
      </li>
      <li class="nav-item">
        <a href="#" style="font-size:20px;">
            <i class="fa fa-credit-card-alt"></i> Payments
        </a>
      </li>
    </ul>
    <a href="logout.php"><button class="btn btn-outline-danger" style="float:right;">Logout</button></a>
  </div>
</nav>

        <div class="main-content">
            <div class="title" style="background:#fff;">
                Users
            </div>
            <div class="main">
                <div class="widget" style="box-shadow: 0 20px 30px rgba(0,0,0,0.5);">
                    <div class="title">Number of users</div>
                    <div class="chart"></div>
                </div>
                <div class="widget"style="box-shadow: 0 20px 30px rgba(0,0,0,0.5);">
                    <div class="title">Number of online users</div>
                    <div class="chart">
                      <div id="custom-search-input" style="margin-top:15px;">
                        <div class="input-group col-md-12">
                          <input id="search" type="text" class="form-control input-lg" placeholder="Search"/>
                            <span class="input-group-btn">
                              <button class="btn btn-primary" type="submit">
                                <i class="material-icons">search</i>
                              </button>
                            </span>
                        </div>
                        <ul class="list-group list-group-flush" style="margin-top:15px;">
                          <?php
                            while ($customer=mysqli_fetch_assoc($users)) {
                                echo '<li class="list-group-item">ID: '.$customer['id'].'</li>';
                                echo '<li class="list-group-item">Activity: '.$customer['last_activity'].'</li>';
                                echo '<li class="list-group-item">Email: '.$customer['email'].'</li>';
                            }
                          ?>
                        </ul>
                      </div>
                    </div>
                </div>
                <div class="widget" style="box-shadow: 0 20px 30px rgba(0,0,0,0.5);">
                    <div class="title">Payments made</div>
                    <div class="chart"></div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script type="text/javascript">
            $(document).on('click','ul li', function(){
                $(this).addClass('active').siblings().removeClass('active')
            })
        </script>
        <script type="text/javascript" src="js/custSearch.js"></script>
</body>
</html>