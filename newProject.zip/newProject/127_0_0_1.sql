-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 15, 2018 at 04:15 AM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `d2d_login`
--
CREATE DATABASE IF NOT EXISTS `d2d_login` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `d2d_login`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `name` text NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`) VALUES
('admin', 'admin4828');

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

DROP TABLE IF EXISTS `login_details`;
CREATE TABLE IF NOT EXISTS `login_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `last_activity` datetime NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`id`, `last_activity`, `email`) VALUES
(23, '2018-09-10 13:34:00', 'pushkars919@gmail.com'),
(22, '2018-09-10 13:31:42', 'pushkars919@gmail.com'),
(21, '2018-09-10 13:19:59', 'pushkars919@gmail.com'),
(20, '2018-09-07 13:09:49', 'pushkars919@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `mobile` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `email`, `password`, `mobile`) VALUES
(19, 'Pushkar', 'Saraf', 'pushkars919@gmail.com', '25f9e794323b453885f5181f1b624d0b', '8983606202'),
(40, 'Uddhav', 'Ghodake', 'uddhavghodake45@gmail.com', '25f9e794323b453885f5181f1b624d0b', '9168499674'),
(41, 'Prashant', 'Saraf', 'sarafprashant07@gmail.com', '25f9e794323b453885f5181f1b624d0b', '8888888888');
--
-- Database: `online_user_test`
--
CREATE DATABASE IF NOT EXISTS `online_user_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `online_user_test`;

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

DROP TABLE IF EXISTS `login_details`;
CREATE TABLE IF NOT EXISTS `login_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `last_activity` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
CREATE TABLE IF NOT EXISTS `user_details` (
  `id` int(10) NOT NULL,
  `user_email` varchar(150) NOT NULL,
  `user_password` varchar(150) NOT NULL,
  `user_type` enum('admin','user') NOT NULL,
  `user_image` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `user_email`, `user_password`, `user_type`, `user_image`) VALUES
(1, 'pushkars919@gmail.com', '839f261a2254dc64958c8c6df2e1a4f1', 'user', ''),
(2, 'admin', 'admin', 'admin', ''),
(3, 'piyushas105@gmail.com', 'tiyu501', 'user', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
