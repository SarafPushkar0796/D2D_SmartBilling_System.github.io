<?php

// Including php files
include("includes/header.php");
include("includes/config.php");
include("includes/checkExistingEmail.php");

session_start();

$msg=''; $msg1=''; $msg2=''; $msg3=''; $msg4=''; $msg5=''; $msg6=''; $msg7=''; $msg8='';
$firstName='';$lastName='';$email_address='';$password='';$mobile='';
if (isset($_POST['submit'])) {
	// 'mysql_real_escape_string' is used to counter sql injection
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$email_address = $_POST['email_address'];
	$password = $_POST['password'];
	$passwordConfirm = $_POST['passwordConfirm'];
	$mobile = false;
	// mobile var is set only if user enters phone number
	if (isset($_POST['mobile'])) {
		$mobile = $_POST['mobile'];
	}
	$checkbox = isset($_POST['checkbox']);

	// Checking for if all fields are filled
	if (strlen($firstName)<3) {
		$msg='<div class="error">First name must contain atleast 3 characters.</div>';
	}
	elseif (strlen($lastName)<3) {
		$msg='<div class="error">Last name must contain atleast 3 characters.</div>';
	}
	elseif (!filter_var($email_address,FILTER_VALIDATE_EMAIL)) {
		$msg2='<div class="error">Please enter valid email address.</div>';
	}
	elseif (email_exists($email_address,$con)) {
		$msg3='<div class="error">Email address already exists.</div>';
	}
	elseif (empty($password)) {
		$msg3='<div class="warn">Please enter password</div>';
	}
	elseif (strlen($password)<7) {
		$msg3='<div class="error">Password must be atleast 7 characters long.</div>';
	}
	elseif ($password!==$passwordConfirm){
		$msg8='<div class="error">Passwords dont match.</div>';
	}
	elseif (strlen($mobile)<10) {
		$msg4='<div class="error">Mobile number must be 10 digits.</div>';
	}
	elseif ($checkbox=='') {
		$msg5='<div class="error">Please agree to terms and conditions.</div>';
	}
	else{

		// Encrypting the password with MD5 hash
		$password=md5($password);

		// If data post from 'form'
		//if ($_POST) {

			// Inserting values into database
			mysqli_query($con,"INSERT INTO users(firstName,lastName,email,password,mobile) 
			VALUES('$firstName','$lastName','$email_address','$password','$mobile')");

			$msg7='<div class="success">Registration successful. Thankyou.</div>';

			// Getting user data from session
			$_SESSION['firstName']=$firstName;
			$_SESSION['lastName']=$lastName;
			$_SESSION['mobile']=$mobile;

			// header("Location: ".$_SERVER['REQUEST_URI']);
			// exit();
		//}
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>D2D Register</title>	
</head>
<style type="text/css">
	.error{
		color: red;
	}	
	.success{
		text-align: center;
		font-weight: bold;
		color: green;
	}
	.warn{
		color: orange;
	}
</style>

<!-- No need for title as includes header.php -->
<body style="background-color: #08AEEA;
background-image: linear-gradient(0deg, #08AEEA 0%, #2AF598 100%);
">
	<div class="container">
		<div class="row">
		<div class="login-form col-md-6 offset-md-3">
			<div class="jumbotron" style="margin-top:130px; margin-bottom:130px; padding:25px; box-shadow: 0 20px 45px rgba(0,0,0,0.3);">

				<!-- Register/Sign in with QR -->
				<h3 align="center" style="margin-bottom:30px;">Register</h3>

				<form method="POST" enctype="multipart/form-data">
					<div class="form-group">
						<!-- <label>First name</label> -->
						<input type="text" name="firstName" placeholder="First name" class="form-control">
						<?php echo $msg; ?>
					</div>
					<div class="form-group">
						<input type="text" name="lastName" placeholder="Last Name" class="form-control">
						<?php echo $msg1; ?>
					</div>
					<div class="form-group">
						<input type="email" name="email_address" placeholder="Email Address" class="form-control">
						<?php echo $msg2; ?>
					</div>
					<div class="form-group">
						<input type="password" name="password" placeholder="Password" class="form-control">
						<?php echo $msg3; ?>
					</div>
					<div class="form-group">
						<input type="password" name="passwordConfirm" placeholder=" Confirm Password" class="form-control">
						<?php echo $msg8; ?>
					</div>
					<div class="form-group">
						<label>Mobile number</label>
						<input type="text" name="mobile" class="input-medium bfh-phone" data-country="IN">
						<?php echo $msg4; ?>
					</div>
					<div class="form-group">
						<input type="checkbox" name="checkbox" id="checkBox"> I agree to the terms and conditions.
							<!-- Modal -->
							<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
							  <div class="modal-dialog" role="document">
							    <div class="modal-content">
							      <div class="modal-header">
							        <h5 class="modal-title" id="exampleModalLongTitle">D2D terms and conditions</h5>
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							          <span aria-hidden="true">&times;</span>
							        </button>
							      </div>
							      <div class="modal-body">
							        <h5>CONDITIONS OF USE</h5>
									Welcome to our online store! D2D and its associates provide their services to you subject to the following conditions. If you visit or shop within this website, you accept these conditions. Please read them carefully.<br/> ​

									<h5>PRIVACY</h5>
									Please review our Privacy Notice, which also governs your visit to our website, to understand our practices.<br/>

									<h5>ELECTRONIC COMMUNICATIONS</h5>
									When you visit D2D or send e-mails to us, you are communicating with us electronically. You consent to receive communications from us electronically. We will communicate with you by e-mail or by posting notices on this site. You agree that all agreements, notices, disclosures and other communications that we provide to you electronically satisfy any legal requirement that such communications be in writing.<br/>

									<h5>COPYRIGHT</h5>
                                    All content included on this site, such as text, graphics, logos, button icons, images, audio clips, digital downloads, data compilations, and software, is the property of D2D or its content suppliers and protected by international copyright laws. The compilation of all content on this site is the exclusive property of D2D, with copyright authorship for this collection by D2D, and protected by international copyright laws.
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-success" data-dismiss="modal">I accept</button>
							      </div>
							    </div>
							  </div>
							</div>
						<?php echo $msg5; ?>
					</div>

					<div class="form-group">
						<input type="submit" value="Register" name="submit" class="btn-primary form-control">
					</div>
					<center><a href="login.php">Already Registered?</a></center><br/>
					<?php echo $msg7; ?>
				</form>
			</div>
		</div>
		</div>
	</div>
	<script type="text/javascript">
		$(function()
		{
		  $('#checkBox').click(function()
		        {
		            if ($('#checkBox').is(":checked")) {
		                $('#exampleModalLong').modal('show');
		            }else {
		                $('#exampleModalLong').modal('hide');
		            }
		        });
		});
	</script>
</body>
</html>