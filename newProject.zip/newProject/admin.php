<?php
include("includes/header.php");
include("includes/config.php");
include("includes/checkExistingEmail.php");
session_start();

$msg=''; $msg1=''; $msg2=''; $name=''; $password='';
if (isset($_POST['submit'])) {
	$name=$_POST['name'];
	$password=$_POST['password'];
	if (empty($name)) {
		$msg='<div class="error">Please enter username.</div>';
	}
	elseif (empty($password)) {
		$msg1='<div class="error">Please enter password.</div>';
	}
	elseif (strlen($password)<7) {
		$msg1='<div class="error">Password must be atleast 7 characters long.</div>';
	}
	else{
		// if exists then check if the password is correct
		// SELECT field_name FROM field_name WHERE field_name..
		$pass=mysqli_query($con,"SELECT password FROM admin WHERE name='$name'");	 // Selecting
		$pass_w=mysqli_fetch_array($pass);  // if found fetch
		$cpass=$pass_w['password'];

		// if no password match from database
		if ($password!=$cpass) {
			$msg1='<div class="error">Password wrong.</div>';		
		}
		else{

			// Getting user name from session
			$_SESSION['name']=$name;

			// if Username and password match
			header("Location:homeAdmin.php");
		}
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>D2D Admin Login</title>	
</head>

<style type="text/css">
	.error{
		color: red;
	}
</style>

<body style="background-color: #74EBD5;
background-image: linear-gradient(90deg, #74EBD5 0%, #9FACE6 100%);
">
	<div class="conatiner">
		<div class="login-form col-md-4 offset-md-4">
			<div class="jumbotron" style="margin-top:70px; margin-bottom:30px; padding:25px; box-shadow: 0 20px 45px rgba(0,0,0,0.3);">
				<h3 align="center" style="margin-bottom:30px;">Admin</h3>
				<?php echo $msg2; ?>
				<form method="POST">
					<div class="form-group">
						<input type="text" name="name" class="form-control" value="<?php echo $name;?>" placeholder="Username">
						<?php echo $msg; ?>
					</div>
					<div class="form-group">
						<input type="password" name="password" class="form-control" value="<?php echo $password;?>" placeholder="Password">
						<?php echo $msg1; ?>
					</div>
					
					<div class="form-group">
						<input type="submit" value="Log in" name="submit" class="btn-success form-control">
					</div>
					<a href="html/userPage.html">Lost?</a>
				</form>
			</div>
		</div>
	</div>
</body>
</html>