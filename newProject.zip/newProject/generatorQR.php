<?php
$code = '<center>
			<img src="https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl='.$_REQUEST['sample'].'" title="Customer Unique ID">
		</center>';
echo $code;
?>