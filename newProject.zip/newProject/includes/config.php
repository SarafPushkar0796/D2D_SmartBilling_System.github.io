<?php
$con=mysqli_connect('localhost','root','','d2d_login');
//$con=mysqli_connect('localhost','id7025418_host_root','host_root','id7025418_d2d');
// $db = new pdo('mysql:host=localhost;dbname=d2d_login','root','');

// Database to display online users
$conOnline = mysqli_connect('localhost','root','','online_user_test');
//$conOnline = mysqli_connect('localhost','id7025418_host_root','host_root','online_user_test'); 
?>