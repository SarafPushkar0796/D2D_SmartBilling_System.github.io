<?php

function email_exists($email_address,$con){
	$row=mysqli_query($con,"SELECT id FROM users WHERE email='$email_address'");
	// Use the below code to see on browser rows affected in database
	// 'print_r()' is for array
	//print_r($row);
	{
		if (mysqli_num_rows($row)==1) {
			return true;
		} else {
			return false;
		}
	}
}

// Not allowing to user returning back to profile page once logged out 
// function check(){
// 	if ($_SESSION['email']=='') {
// 		return true;
// 	} else {
// 		return false;
// 	}
// }

function check(){
	if ($_SESSION['email']=='') {
		return true;
	} else {
		return false;
	}
}

// Not allowing to user returning back to adminHome page once logged out 
function check_admin(){
	if ($_SESSION['name']=='') {
		return true;
	} else {
		return false;
	}
}

?>