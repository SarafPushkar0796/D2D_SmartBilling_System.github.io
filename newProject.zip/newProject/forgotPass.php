<?php
include("includes/header.php");
include("includes/config.php");
include("includes/checkExistingEmail.php");
session_start();

$msg=''; $msg1=''; $msg2='';$msg3='';$msg4='';
if (isset($_POST['submit'])) {
	$email=$_POST['email'];
	$password=$_POST['pass'];
	$cpassword=$_POST['cpass'];
	$mobile=false;
	// mobile var is set only if user enters phone number
	if (isset($_POST['mobile'])) {
		$mobile = $_POST['mobile'];
	}
	if (empty($email)) {
		$msg='<div class="error">Please enter email.</div>';
	}
	elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$msg='<div class="error">Please enter valid email address.</div>';
	}
	elseif (empty($password)) {
		$msg1='<div class="error">Please enter new password.</div>';
	}
	elseif (empty($cpassword)) {
		$msg2='<div class="error">Please confirm password.</div>';
	}
	elseif($password!=$cpassword){
		$msg2='<div class="error">Passwords dont match.</div>';
	}
	elseif (strlen($password)<7) {
		$msg1='<div class="error">Password must be atleast 7 characters long.</div>';
	}
	elseif (strlen($mobile)<10) {
		$msg3='<div class="error">Mobile number must be 10 digits.</div>';
	}
	elseif (email_exists($email,$con)) {
		// if exists then check if the password is correct
		// SELECT field_name FROM field_name WHERE field_name..
		$result=mysqli_query($con,"SELECT mobile FROM users WHERE email='$email'");	 // Selecting
		$userMobile=mysqli_fetch_array($result);  // if found fetch
		$checkMobile=$userMobile['mobile'];
		if($mobile==$checkMobile){
			$pass=md5($password);
			mysqli_query($con,"UPDATE users SET password='$pass'");
			$msg4='<div class="success">Password changed successfully.</div>';
		} else {
			$msg4='<div class="success">Mobile number not found.</div>';
		}
	}
	else{
		$msg='<div class="error">Email does not exists. Please register.</div>';
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Forgot password</title>	
</head>

<style type="text/css">
	.error{
		color: red;
	}
	.success{
		text-align: center;
		font-weight: bold;
		color: green;
	}
</style>

<body style="background-color: #FBAB7E;
background-image: linear-gradient(62deg, #FBAB7E 0%, #F7CE68 100%);

">
	<div class="container">
		<div class="row">
		<div class="login-form col-md-6 offset-md-3">
			<div class="jumbotron" style="margin-top:70px; margin-bottom:30px; padding:25px; box-shadow: 0 20px 45px rgba(0,0,0,0.3);">
				<h3 align="center" style="margin-bottom:30px;">Forgot password</h3>
				<?php echo $msg4;?>
				<form method="POST">
					<div class="form-group">
						<input type="email" name="email" class="form-control" placeholder="Email address">
						<?php echo $msg; ?>
					</div>
					<div class="form-group">
						<label>Mobile number</label>
						<input type="text" name="mobile" class="input-medium bfh-phone" data-country="IN">
						<?php echo $msg3; ?>
					</div>
					<div class="form-group">
						<input type="password" name="pass" class="form-control" placeholder="New password">
						<?php echo $msg1; ?>
					</div>
					<div class="form-group">
						<input type="password" name="cpass" class="form-control" placeholder="Re-enter new password">
						<?php echo $msg2; ?>
					</div>
					<div class="form-group">
						<input type="submit" value="Change Password" name="submit" class="btn-primary form-control">
					</div>
					<center><a href="login.php">Login Page</a></center>
				</form>
			</div>
		</div>
	</div>
	</div>
</body>
</html>