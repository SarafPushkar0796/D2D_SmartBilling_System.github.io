<?php
include("includes/header.php");
include("includes/config.php");
include("includes/checkExistingEmail.php");
session_start();

$msg=''; $msg1=''; $msg2='';$email='';$msg3='';$row='';$credential='';
if (isset($_POST['submit'])) {
	$email=$_POST['email'];
	$password=$_POST['password'];
	if (empty($email)) {
		$msg='<div class="error">Please enter email.</div>';
	}
	elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$msg='<div class="error">Please enter valid email address.</div>';
	}
	elseif (empty($password)) {
		$msg1='<div class="error">Please enter password.</div>';
	}
	elseif (strlen($password)<7) {
		$msg1='<div class="error">Password must be atleast 7 characters long.</div>';
	}
	elseif (email_exists($email,$con)) {
		// if exists then check if the password is correct
		// SELECT field_name FROM field_name WHERE field_name..
		$pass=mysqli_query($con,"SELECT password FROM users WHERE email='$email'");	 // Selecting
		$pass_w=mysqli_fetch_array($pass);  // if found fetch
		$cpass=$pass_w['password'];

		// Encrypting entered password
		$password=md5($password);

		// if no password match from database
		if ($password!=$cpass) {
			$msg1='<div class="error">Password wrong.</div>';		
		} else {

			// Getting user email from session
			$_SESSION['email']=$email;

			// Sending Data for online users
			mysqli_query($con,"INSERT INTO login_details(last_activity,email) VALUES(CURRENT_TIMESTAMP,'$email')");

			// if email and password match
			header("Location: homeCustomer.php");
		}
	} else {
		$msg='<div class="error">Email does not exists. Please register.</div>';
	}
}

// checking from db if email exists from scanned QR
if(isset($_POST['submitID'])){
	// $credential = '<script>document.write(document.getElementById("dbr").innerHTML)</script>'; 
	$emailID=$_POST['credentialCarrier'];	// Hardcoded
	 if(email_exists($emailID,$con)){
	 	$checkEmail=mysqli_query($con,"SELECT email FROM users WHERE email='$emailID'");
	 	$checkEmail_a=mysqli_fetch_array($checkEmail,MYSQLI_BOTH);
	 	$checkEmail_b=$checkEmail_a['email'];
	 	if($checkEmail_b==$emailID){
	 		$_SESSION['email']=$emailID;
	 		header("Location: homeCustomer.php");
	 		// echo '<script type="text/javascript">window.location.replace("homeCustomer.php");</script>';
	 	} else {
	 		$msg3='<div class="error">Email does not exists.</div>';
	 	}
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<script src="js/jquery-1.11.3.min.js"></script>
	<title>D2D Login</title>	
	<script type="text/javascript">
		function myCredential(){
			credential =  $('#dbr').html();

			$("#credentialCarrier").val(credential);
			console.log(credential);

			$("#submitCred").submit();
		}
	</script>
</head>

<style type="text/css">
	.error{
		color: red;
	}
	.success{
		text-align: center;
		color: green;
	}
</style>

<body style="background-color: #74EBD5;background-image: linear-gradient(90deg, #74EBD5 0%, #9FACE6 100%);">
	<div class="container">
		<div class="row">
		<div class="login-form col-md-6 offset-md-3">
			<div class="jumbotron" style="margin-top:70px; margin-bottom:30px; padding:25px; box-shadow: 0 20px 45px rgba(0,0,0,0.3);">
				<h3 align="center" style="margin-bottom:30px;">Log in</h3>
				<?php echo $msg2; ?>
				<form method="POST">
					<div class="form-group">
						<input type="email" name="email" class="form-control" placeholder="Email address">
						<?php echo $msg; ?>
					</div>
					<div class="form-group">
						<input type="password" name="password" class="form-control" placeholder="Password">
						<?php echo $msg1; ?>
					</div>
					<div class="form-group">
						<input type="submit" value="Log in" name="submit" class="btn-primary form-control">
					</div>
					<div class="form-group">
						<center><p>Or</p></center>
						<button type="button" class="btn-success form-control" data-toggle="modal" data-target="#exampleModal">Login with your QR-ID</button>
					</div>
					<a href="signUp.php">Not registered?</a>
					<a style="float: right;" href="forgotPass.php">Forgot password?</a><br/>
					<center><?php echo $msg3;?></center>
				</form>
			</div>
		</div>
	</div>
	</div>
	<!-- Modal -->
	<div class="modal fade bd-example-modal-lg" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-lg" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Please hold your Unique QR-ID still.</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>

	      <!-- Modal body -->
		        <div class="modal-body">
				  <div class="select">
				    <center><label for="videoSource">Video source: </label><select id="videoSource"></select></center>
				  </div>
				  
				  <center>
				  <div align="center">
				    <video muted autoplay id="video" playsinline="true" style="width: 450px;height: 450px;"></video>
				    <canvas id="pcCanvas" width="320" height="320" style="display: none; float: bottom;"></canvas>
				    <canvas id="mobileCanvas" width="320" height="320" style="display: none; float: bottom;"></canvas>
				  </div>
				  </center>
				  <br/>

				  <!-- Read barcode -->
				  <form method="post" action="login.php">
					  <center><button type="button" class=" btn btn-success" id="go">Read QR</button></center><br/>
					  <center>QR Result: <span id="dbr" name="credential" class="success"></span></center>

					  <input type="hidden" name="credentialCarrier" id="credentialCarrier">
					  <input onclick="myCredential()" id="submitCred" type="submit" value="Confirm ID" name="submitID" class="btn btn-primary" style="float: right;">
				  </form>
		        </div>
	        <div class="modal-footer">
	          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
	        </div>
	    </div>
	  </div>
	</div>
</body>
<script async src="js/zxing.js"></script>
<script src="js/video.js"></script>
</html>