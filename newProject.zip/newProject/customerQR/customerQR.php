<?php
include("../includes/header.php");
include("../includes/checkExistingEmail.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css">
	<title>QR Code generation</title>
</head>
<body style="background-color: #74EBD5;
background-image: linear-gradient(90deg, #74EBD5 0%, #9FACE6 100%);
">
	<div class="container">
		<div class="login-form col-md-6 offset-md-3">
			<div class="jumbotron" style="margin-top:70px; margin-bottom:30px; padding:25px; box-shadow: 0 20px 45px rgba(0,0,0,0.3);">
				<h3 align="center" style="margin-bottom:30px;">My QR</h3>
				<form method="POST">
					<div class="form-group">
						<input onkeyup="generate_qrcode(this.value)" type="email" name="email" class="form-control" placeholder="Email address">
					</div>
					<div class="form-group">
						<center><label style="color:green;">QR will generate as you type</label></center>
					</div>
					<div id="result"></div><br/>
					<div class="form-group">
						<input type="submit" value="Send to my email" name="submit" class="btn-primary form-control">
					</div>
					<label style="color:red;">Note: Use this QR to login next time.</label>
				</form>
			</div>
		</div>
	</div>
</body>
<script>
 	function generate_qrcode(sample){
 		$.ajax({
	 		type: 'post',
	 		url: 'generator.php',
	 		data : {sample:sample},
	 		success: function(code){
	 			$('#result').html(code);
	 		}
 		});
 	}
</script>
</html>