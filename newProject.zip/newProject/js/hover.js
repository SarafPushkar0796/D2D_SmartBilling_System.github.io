//$('#check').popover({ trigger: "hover" });
$('#check').popover('toggle');