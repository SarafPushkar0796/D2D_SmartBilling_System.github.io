function addItem(){
  var ul = document.getElementById("list");
  var candidate1 = $('#dbr').html();
  $('#productCarrier').val(candidate1);
  var candidate = document.getElementById("productCarrier");
  var li = document.createElement("li");
  li.setAttribute('id',candidate.value);
  li.appendChild(document.createTextNode(candidate.value));
  ul.appendChild(li);
}

function removeItem(){
  var ul = document.getElementById("list");
  var candidate2 = $('#dbr').html();
  $('#productCarrier').val(candidate2);
  var candidate = document.getElementById("productCarrier");
  var item = document.getElementById(candidate.value);
  ul.removeChild(item);
}