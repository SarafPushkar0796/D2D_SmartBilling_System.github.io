var product = $('#dbr').html();
var newItem = $('#productCarrier').val(product);
console_log(product);


<?php
include("includes/header.php");
include("includes/checkExistingEmail.php");
//session_start();
if (check()) {
	header("Location:login.php");
}
$email=$_SESSION['email'];

// Sending QR code via email
$mail_message = '';
if(isset($_POST['submit'])){

	require 'PHPMailer/PHPMailerAutoload.php';

	// instance of PHPMailer
	$mail=new PHPMailer();

	// enable SMTP
	$mail->IsSMTP();

	// set a Host
	$mail->Host = "smtp.gmail.com";

	// set authentication to true
	$mail->SMTPAuth = true;

	// set login details for gmail account
	$mail->Username = "teampaaus.6@gmail.com";
	$mail->Password = "teamp@aus18";

	// type of protection
	$mail->SMTPSecure = "tls";

	// set port
	$mail->Port = 587;

	// subject
	$mail->Subject = "D2D QR login";
	
    // type
    $mail->isHTML(true);
    
    $image = 'https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl='.$_REQUEST['sample']; //Working with no value in qr
    $image = file_get_contents($image);
	
	// Body
    $mail->Body = '<p>Please hereby find your <strong>unique QR.</strong></p><p><img src="cid:qrcode" /></p>';
    
    $mail->addStringEmbeddedImage($image,'qrcode','qrcode.jpg');

	// set who is sending email
	$mail->setFrom('teampaaus.6@gmail.com','D2D Support Team');

	// recipient
	$mail->addAddress($_POST['email']);

	// send
	if($mail->send()){
		$mail_message = '<div class="success">Mail sent.</div>';
	} else {
		$mail_message = '<div class="danger">Mail not sent.</div>'. $mail->ErrorInfo;;
	}
}
?>

<!-- While using session you always have to start from first page  -->

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/homeCustomer.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<link rel="stylesheet" type="text/css" href="css/floatingButton.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

	<!-- QR generation JQuery script -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<title>Home Page</title>
</head>
<style type="text/css">
	.error{
		color: red;
	}	
	.success{
		text-align: center;
		font-weight: bold;
		color: green;
	}
	.warn{
		color: orange;
	}
</style>

<body id="body-bg">
	<!-- Navigation Bar -->
	<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color:#fafafa;box-shadow: 0 3px 40px rgba(0,0,0,0.3);">
  		<img src="images/d2d2.png" style="margin: 10px;height:80px; width:80px;"/>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav mr-auto">
		    	<li class="nav-item">
		        	<button type="button" onclick="overlay()" data-toggle="modal" data-target="#myModal" class="btn btn-outline-success">Generate QR</button>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="#">Home</a>
		      	</li>
		      	<li class="nav-item">
		        	<a class="nav-link" href="#">Link</a>
		      	</li>
		    </ul>
		    <a href="logout.php"><button class="btn btn-outline-danger" style="float:right;">Logout</button></a>
		  </div>
	</nav>

	<div class="row">
		<div class="container" style="padding-top:5px;margin-top:20px;margin-bottom:20px;height:630px;width:1800px;background-color:#fafafa; border-radius:7px;">
			<div class="alert alert-success" role="alert" style="margin-top:70px;">
		  		Logged in Successfully!
			</div>
			<?php echo $email;?>
		</div>
	</div>

	<!-- Custom Modal for QR generation -->	
		<div id="overlay" style="visibility: hidden;position: absolute;left: 0px;top: 0px;width:100%;height:100%;text-align:center;z-index: 1000;">
		        <div class="container">
					<div class="login-form col-md-6 offset-md-3">
						<div class="jumbotron" style="margin-top:70px; margin-bottom:30px; padding:25px; box-shadow: 0 20px 45px rgba(0,0,0,0.3);">
							<button type="button" class="close" onclick="overlay()">&times;</button>
							<h3 align="center" style="margin-bottom:30px;">My QR</h3>
							<form method="POST">
								<div class="form-group">
									<input onkeyup="generate_qrcode(this.value)" type="email" name="email" class="form-control" placeholder="Email address">
								</div>
								<div class="form-group">
									<center><label style="color:green;">QR will generate as you type</label></center>
								</div>
								
								<!-- displaying the QR value -->
								<div id="result"></div><br/>
								
								<div class="form-group">
									<input type="submit" value="Send to my email" name="submit" class="btn-primary form-control">
								</div>
								<label style="color:red;">Note: Use this QR to login next time.</label>
							    <?php echo $mail_message;?>
							</form>
						</div>
					</div>
				</div>
		</div>
		
		<!-- Floating button -->
		<a href="#" class="float">
			<i class="fa fa-plus my-float"></i>
		</a>

	<!-- JavaScript for functioning of Custom Modal -->
	<script type="text/javascript">

		// Displaying or hiding modal 
		function overlay() {
			el = document.getElementById("overlay");
			el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
		}

		// QR generation
		function generate_qrcode(sample){
 		$.ajax({
	 		type: 'post',
	 		url: 'generatorQR.php',
	 		data : {sample:sample},
	 		success: function(code){
	 		 	$('#result').html(code);
	 		}
 		});
 	}
	</script>
</body>
</html>